<?php 

$string = "
 <div class=\"content-wrapper\">
    <section class=\"content-header\">
      <div class=\"container-fluid\">
        <div class=\"row mb-2\">
          <div class=\"col-sm-6\">
            <h1>".ucfirst($table_name)."</h1>
          </div>
          <div class=\"col-sm-6\">
            <ol class=\"breadcrumb float-sm-right\">
              <li class=\"breadcrumb-item\"><a href=\"#\">".ucfirst($table_name)."</a></li>
              <li class=\"breadcrumb-item active\">Read</li>
            </ol>
          </div>
        </div>
      </div>
    </section> 
 <section class=\"content\">
      <div class=\"row\">
        <div class=\"col-md-12\">
          <div class=\"card card-primary\">
            <div class=\"card-header\">
              <h3 class=\"card-title\">".ucfirst($table_name)." List</h3>

              <div class=\"card-tools\">
                <button type=\"button\" class=\"btn btn-tool\" data-card-widget=\"collapse\" title=\"Collapse\">
                  <i class=\"fas fa-minus\"></i>
                </button>
              </div>
            </div>
            
            <div class=\"card-body\">
              <form role=\"form\" >
        <table class=\"table\">";
foreach ($non_pk as $row) {
    $string .= "\n\t    <tr><td>".label($row["column_name"])."</td><td><?php echo $".$row["column_name"]."; ?></td></tr>";
}
$string .= "\n\t    <tr><td></td><td><a href=\"<?php echo site_url('".$c_url."') ?>\" class=\"btn btn-default\">Cancel</a></td></tr>";
$string .= "\n\t</table>
       
              </form>
             <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        
      </div>
    
    </section>
    <!-- /.content -->
  </div>";



$hasil_view_read = createFile($string, $target."views/" . $c_url . "/" . $v_read_file);

?>