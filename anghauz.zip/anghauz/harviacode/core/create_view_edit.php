<?php 


$string = "
<div class=\"d-sm-flex align-items-center justify-content-between mb-4\">
                        <h1 class=\"h3 mb-0 text-gray-800\">".ucfirst($table_name)."</h1>
                    </div>
 <div class=\"card shadow mb-4\">

 <div class=\"card-header py-3\">
  <h6 class=\"m-0 font-weight-bold text-primary\">".ucfirst($table_name)." List</h6>
         
</div>
       <div class=\"card-body\">      
    <table class=\"table table-bordered table-striped \" style=\"margin-bottom: 10px\" id=\"tabel\">
            
        </table>    </div> 
        </div>
<div class=\"modal fade\" id=\"modal-default\">
        <div class=\"modal-dialog\">
          <div class=\"modal-content\">
            <div class=\"modal-header bg-success\">
              <h4 class=\"modal-title\">".ucfirst($c_url)." Edit</h4>
              <a href=\"<?php echo site_url('".$c_url."') ?>\" type=\"button\"  aria-label=\"Close\">
                <span aria-hidden=\"true\">&times;</span>
              </a>
            </div>
            <div class=\"modal-body\"> 
            <form  action=\"<?php echo \$action; ?>\" method=\"post\">
                ";
foreach ($non_pk as $row) {
    if ($row["data_type"] == 'text')
    {
    $string .= "\n\t    <div class=\"form-group\">
            <label for=\"".$row["column_name"]."\">".label($row["column_name"])." <?php echo form_error('".$row["column_name"]."') ?></label>
            <textarea class=\"form-control\" rows=\"3\" name=\"".$row["column_name"]."\" id=\"".$row["column_name"]."\" placeholder=\"".label($row["column_name"])."\"><?php echo $".$row["column_name"]."; ?></textarea>
        </div>";
    } else
    {
    $string .= "\n\t    <div class=\"form-group\">
            <label for=\"".$row["data_type"]."\">".label($row["column_name"])." <?php echo form_error('".$row["column_name"]."') ?></label>
            <input type=\"text\" class=\"form-control\" name=\"".$row["column_name"]."\" id=\"".$row["column_name"]."\" placeholder=\"".label($row["column_name"])."\" value=\"<?php echo $".$row["column_name"]."; ?>\" required/>
        </div>";
    }
} 
               
            
$string .= "\n\t   </div>
            <div class=\"modal-footer justify-content-between\">
             <input type=\"hidden\" name=\"".$pk."\" value=\"<?php echo $".$pk."; ?>\" /> ";
$string .= "\n\t    <button type=\"submit\" class=\"btn btn-success\"><?php echo \$button ?></button> ";
$string .= "\n\t    <a href=\"<?php echo site_url('".$c_url."') ?>\" class=\"btn btn-default\">Cancel</a></div>";
$string .= "\n\t     
                
             </form>
          </div> 
        </div> 
      </div> 

      <script type=\"text/javascript\">
    window.onload = function () {
        OpenBootstrapPopup();
    };
    function OpenBootstrapPopup() {
        $(\"#modal-default\").modal({backdrop: 'static', 'show':true}); 
    }
</script> ";

$hasil_view_form = createFile($string, $target."views/" . $c_url . "/" . $v_edit_file);

?>