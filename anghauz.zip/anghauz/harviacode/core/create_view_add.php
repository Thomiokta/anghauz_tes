<?php 


$string = "
<div class=\"modal fade\" id=\"modal-default\" tabindex=\"-1\" role=\"dialog\"aria-labelledby=\"exampleModalLabel\"
        aria-hidden=\"true\" >
        <div class=\"modal-dialog\" role=\"document\">
          <div class=\"modal-content \">
            <div class=\"modal-header bg-primary\">
              <h4 class=\"modal-title\"id=\"exampleModalLabel\">".ucfirst($c_url)." Input</h4>
              <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">
                <span aria-hidden=\"true\">&times;</span>
              </button>
            </div>
            <div class=\"modal-body\"> 
            <form  action=\"<?php echo \$action; ?>\" method=\"post\">
                ";
foreach ($non_pk as $row) {
    if ($row["data_type"] == 'text')
    {
    $string .= "\n\t    <div class=\"form-group\">
            <label for=\"".$row["column_name"]."\">".label($row["column_name"])." <?php echo form_error('".$row["column_name"]."') ?></label>
            <textarea class=\"form-control\" rows=\"3\" name=\"".$row["column_name"]."\" id=\"".$row["column_name"]."\" placeholder=\"".label($row["column_name"])."\"><?php echo $".$row["column_name"]."; ?></textarea>
        </div>";
    } else
    {
    $string .= "\n\t    <div class=\"form-group\">
            <label for=\"".$row["data_type"]."\">".label($row["column_name"])." <?php echo form_error('".$row["column_name"]."') ?></label>
            <input type=\"text\" class=\"form-control\" name=\"".$row["column_name"]."\" id=\"".$row["column_name"]."\" placeholder=\"".label($row["column_name"])."\" value=\"<?php echo $".$row["column_name"]."; ?>\" required/>
        </div>";
    }
} 
               
            
$string .= "\n\t   </div>
            <div class=\"modal-footer justify-content-between\">
             <input type=\"hidden\" name=\"".$pk."\" value=\"<?php echo $".$pk."; ?>\" /> ";
$string .= "\n\t    <button type=\"submit\" class=\"btn btn-primary\"><?php echo \$button ?></button> ";
$string .= "\n\t    <a href=\"<?php echo site_url('".$c_url."') ?>\" class=\"btn btn-default\">Cancel</a></div>";
$string .= "\n\t     
                
             </form>
          </div> 
        </div> 
      </div> 

      ";

$hasil_view_form = createFile($string, $target."views/" . $c_url . "/" . $v_add_file);

?>