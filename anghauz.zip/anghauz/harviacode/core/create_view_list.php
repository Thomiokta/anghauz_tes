<?php 

$string = "     <div class=\"d-sm-flex align-items-center justify-content-between mb-4\">
                        <h1 class=\"h3 mb-0 text-gray-800\">".ucfirst($table_name)."</h1>
                    </div>
 <div class=\"card shadow mb-4\">

 <div class=\"card-header py-3\">
  <h6 class=\"m-0 font-weight-bold text-primary\">".ucfirst($table_name)." List</h6>
         
</div>
       <div class=\"card-body\">      
    <a href=\"#\" class=\"btn btn-primary btn-circle\" data-toggle=\"modal\" data-target=\"#modal-default\">
                                        <i class=\"fas fa-plus\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"Create\"></i>
                                    </a>

        <table class=\"table table-bordered table-striped \" style=\"margin-bottom: 10px\" id=\"tabel\">
            <thead><tr>
                <th>No</th>";
foreach ($non_pk as $row) {
    $string .= "\n\t\t<th>" . label($row['column_name']) . "</th>";
}
$string .= "\n\t\t<th>Action</th>
            </tr></thead><tbody>";
$string .= "<?php
            foreach ($" . $c_url . "_data as \$$c_url)
            {
                ?>
                <tr>";

$string .= "\n\t\t\t<td width=\"80px\"><?php echo ++\$start ?></td>";
foreach ($non_pk as $row) {
    $string .= "\n\t\t\t<td class=\"table_data\" data-row_id=\"<?php echo $".$c_url."->".$pk." ?>\" data-column_name=\"". $row['column_name'] . "\" contenteditable><?php echo $" . $c_url ."->". $row['column_name'] . " ?></td>";
}


$string .= "\n\t\t\t<td style=\"text-align:center; min-width: 110px;\"  >"
        . "\n\t\t\t\t<?php "
        . "\n\t\t\t\techo anchor(site_url('".$c_url."/read/'.$".$c_url."->".$pk."),'<i class=\"fas fa-eye\"></i>','class=\"btn btn-info btn-circle\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"Read\"'); " 
        . "\n\t\t\t\techo anchor(site_url('".$c_url."/update/'.$".$c_url."->".$pk."),'<i class=\"fas fa-edit\"></i>','class=\"btn btn-success btn-circle\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"Edit\"'); " 
        . "\n\t\t\t\techo anchor(site_url('".$c_url."/delete/'.$".$c_url."->".$pk."),'<i class=\"fas fa-trash\"></i>','class=\"btn btn-danger btn-circle alert_notif\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"Delete\"'); "
        . "\n\t\t\t\t?>"
        . "\n\t\t\t</td>";

$string .=  "\n\t\t</tr>
                <?php
            }
            ?></tbody>
        </table>  
          </div> 
        </div>
        
 <?php \$this->load->view('".ucfirst($c_url)."/".$c_url."_add')?> 
 <script src=\"<?php echo base_url()?>asset/vendor/jquery/jquery-3.7.1.min.js\"></script>
 <script>
\$(document).ready(function(){  
 \$(document).on('blur', '.table_data', function(){
    var id = \$(this).data('row_id');
    var table_column = \$(this).data('column_name');
    var value = \$(this).text();
    \$.ajax({
      url:\"<?php echo base_url(); ?>".ucfirst($c_url)."/live_update\",
      method:\"POST\",
      data:{id:id, table_column:table_column, value:value},
      success:function(data)
      {
        Swal.fire({
  icon: 'success',
  title: 'Edit Success ',
  showConfirmButton: false,
  timer: 1000
}) 
        load_data();
      }
    })
  });
 

});
</script>";

if ($export_excel == '1') {
    $string .= "\n\t\t<?php echo anchor(site_url('".$c_url."/excel'), 'Excel', 'class=\"btn btn-primary\"'); ?>";
}
if ($export_word == '1') {
    $string .= "\n\t\t<?php echo anchor(site_url('".$c_url."/word'), 'Word', 'class=\"btn btn-primary\"'); ?>";
}
if ($export_pdf == '1') {
    $string .= "\n\t\t<?php echo anchor(site_url('".$c_url."/pdf'), 'PDF', 'class=\"btn btn-primary\"'); ?>";
}



$hasil_view_list = createFile($string, $target."views/" . $c_url . "/" . $v_list_file);

?>